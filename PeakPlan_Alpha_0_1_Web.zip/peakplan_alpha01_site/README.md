# PeakPlan Alpha 0.1

Dette er en enkel første webversjon av PeakPlan.

## Slik bruker du den
- Åpne `index.html` i nettleser, eller legg filene i et GitHub-repo og publiser med GitHub Pages/Vercel.
- Bruk fanene i appen for å teste flyten.
- Juster tid, mål og pendling.

## Filene
- `index.html`
- `styles.css`
- `app.js`

## Neste steg
- Lage en mer robust versjon
- Legge til lagring
- Koble på Strava senere
- Lage eksport til Zwift senere
