const state = {
  tab: "home",
  focus: "Begge",
  ftp: 295,
  commuteDays: 3,
  commuteMinutes: 45,
  includeZwift: true,
  lifeHappened: false,
  availability: JSON.parse(JSON.stringify([
    { day: "Mon", minutes: 0, preferred: "Sykkel" },
    { day: "Tue", minutes: 50, preferred: "Løp" },
    { day: "Wed", minutes: 45, preferred: "Sykkel" },
    { day: "Thu", minutes: 75, preferred: "Løp" },
    { day: "Fri", minutes: 0, preferred: "Sykkel" },
    { day: "Sat", minutes: 120, preferred: "Sykkel" },
    { day: "Sun", minutes: 90, preferred: "Løp" },
  ])),
  goals: JSON.parse(JSON.stringify([
    { id: "g1", title: "Birken sykkel", type: "Ritt", date: "2026-09-12", priority: 1 },
    { id: "g2", title: "Halvmaraton", type: "Løp", date: "2026-10-04", priority: 2 },
  ])),
};

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const DAY_LABELS = {
  Mon: "Mandag",
  Tue: "Tirsdag",
  Wed: "Onsdag",
  Thu: "Torsdag",
  Fri: "Fredag",
  Sat: "Lørdag",
  Sun: "Søndag",
};

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

function z2(ftp) {
  return `${Math.round(ftp * 0.56)}-${Math.round(ftp * 0.75)} W`;
}

function tempo(ftp) {
  return `${Math.round(ftp * 0.76)}-${Math.round(ftp * 0.87)} W`;
}

function sweetSpot(ftp) {
  return `${Math.round(ftp * 0.88)}-${Math.round(ftp * 0.94)} W`;
}

function threshold(ftp) {
  return `${Math.round(ftp * 0.95)}-${Math.round(ftp * 1.05)} W`;
}

function phaseFromGoal(goalDate) {
  if (!goalDate) return "Base";
  const diffDays = Math.ceil((new Date(goalDate).getTime() - Date.now()) / 86400000);
  if (diffDays > 84) return "Base";
  if (diffDays > 42) return "Build";
  if (diffDays > 14) return "Spesifikk";
  return "Taper";
}

function sortGoals(goals) {
  return [...goals].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
}

function generatePlan() {
  const latestGoal = sortGoals(state.goals)[0];
  const phase = phaseFromGoal(latestGoal?.date || "");
  const available = state.availability.filter((d) => d.minutes > 0);
  const longest = [...available].sort((a, b) => b.minutes - a.minutes)[0] || available[0];
  const intervalDay = [...available].sort((a, b) => b.minutes - a.minutes)[1] || longest;
  const recoveryDay = available.find((d) => d.minutes <= 60) || available[0];

  return DAYS.map((day) => {
    const slot = state.availability.find((d) => d.day === day) || { minutes: 0, preferred: "Sykkel" };
    const commute = ["Mon", "Wed", "Fri"].includes(day) && state.commuteDays > 0 && state.commuteMinutes > 0;

    if (!slot.minutes && !commute) {
      return { day, type: "Hvile", title: "Hvile", duration: 0, details: "Ingen planlagt økt.", zwift: false };
    }

    if (commute) {
      return {
        day,
        type: "Pendling",
        title: "Sykle til/fra jobb",
        duration: state.commuteMinutes,
        details: "Telles som lavintensivt volum og justerer resten av uka.",
        zwift: false,
      };
    }

    if (day === longest.day) {
      const isRun = state.focus === "Løp" || (state.focus === "Begge" && slot.preferred === "Løp");
      return {
        day,
        type: isRun ? "Løp" : "Sykkel",
        title: isRun ? "Langtur rolig" : "Langkjøring sone 2",
        duration: clamp(Math.round(slot.minutes * 0.9), 45, 180),
        details: isRun
          ? "Rolig pratetempo. Bygger kapasitet uten å stjele energi."
          : `Hold jevnt i ${z2(state.ftp)}. Fokus på flyt og kontroll.`,
        zwift: !isRun && state.includeZwift,
      };
    }

    if (day === intervalDay.day && phase !== "Base") {
      const detailsByPhase = {
        Build: `2 x 20 min i ${sweetSpot(state.ftp)} med 5 min pause.`,
        Spesifikk: `5 x 4 min i ${Math.round(state.ftp * 1.08)}-${Math.round(state.ftp * 1.18)} W.`,
        Taper: `6 x 2 min i ${tempo(state.ftp)}. Kort og skarpt.`,
      };
      const titleByPhase = {
        Build: "Sweet Spot",
        Spesifikk: "VO2-økt",
        Taper: "Skarphet",
      };
      return {
        day,
        type: state.focus === "Løp" ? "Løp" : "Sykkel",
        title: titleByPhase[phase],
        duration: clamp(Math.round(slot.minutes * 0.8), 40, 110),
        details: detailsByPhase[phase] || `3 x 12 min i ${threshold(state.ftp)}.`,
        zwift: state.focus !== "Løp" && state.includeZwift,
      };
    }

    if (day === recoveryDay.day) {
      return {
        day,
        type: state.focus === "Løp" ? "Løp" : "Sykkel",
        title: "Rolig restitusjon",
        duration: clamp(Math.round(slot.minutes * 0.6), 25, 60),
        details: state.focus === "Løp" ? "Kort og lett jogg." : `Hold deg i ${z2(state.ftp)} og la beina hente seg inn.`,
        zwift: state.focus !== "Løp" && state.includeZwift,
      };
    }

    const isRun = state.focus === "Løp" || (state.focus === "Begge" && slot.preferred === "Løp");
    return {
      day,
      type: isRun ? "Løp" : "Sykkel",
      title: isRun ? "Rolig løp" : "Aerob base",
      duration: clamp(Math.round(slot.minutes * 0.75), 30, 90),
      details: isRun ? "Snakkefart og lav friksjon." : `Jevn tråkking i ${z2(state.ftp)}.`,
      zwift: !isRun && state.includeZwift,
    };
  });
}

function phaseLabel() {
  const latestGoal = sortGoals(state.goals)[0];
  return phaseFromGoal(latestGoal?.date || "");
}

function trainingMinutes(plan) {
  return plan.filter((item) => item.type !== "Hvile").reduce((sum, item) => sum + item.duration, 0);
}

function chips(plan) {
  const latestGoal = sortGoals(state.goals)[0];
  return [
    { text: phaseLabel() },
    { text: `${trainingMinutes(plan)} min trening` },
    { text: `${state.commuteDays * state.commuteMinutes} min pendling` },
    { text: latestGoal ? `${latestGoal.title} • ${latestGoal.date}` : "Legg inn mål" },
  ];
}

function render() {
  const plan = generatePlan();
  const latestGoal = sortGoals(state.goals)[0];
  const currentTab = state.tab;
  const root = document.getElementById("app");
  document.getElementById("chips").innerHTML = chips(plan)
    .map((chip) => `<span class="chip">${chip.text}</span>`)
    .join("");

  document.querySelectorAll(".tab").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.tab === currentTab);
  });

  document.querySelectorAll(".view").forEach((view) => view.classList.remove("active"));
  document.getElementById(currentTab).classList.add("active");

  document.getElementById("home").innerHTML = `
    <div class="grid two">
      <div class="card">
        <div class="recommendation">
          <div class="small">Dagens anbefaling</div>
          <h2>${state.lifeHappened ? "Livet skjedde" : "Én tydelig økt som passer dagen din"}</h2>
          <p>${state.lifeHappened ? "Ingen problem. Vi justerer planen. Dagens beste valg er en rolig økt eller hvile." : "PeakPlan prioriterer det som gir mest effekt med minst stress. Målet er kontinuitet, ikke perfeksjon."}</p>
          <div class="btn-row">
            <button class="btn primary" id="toggle-life">${state.lifeHappened ? "Tilbake til normal" : "Livet skjedde"}</button>
            <button class="btn secondary" data-go-tab="plan">Se planen</button>
          </div>
        </div>

        <div class="kpi-grid" style="margin-top:16px">
          <div class="kpi">
            <div class="label">FTP</div>
            <div class="value">${state.ftp} W</div>
            <div class="hint">Sone 2: ${z2(state.ftp)}</div>
          </div>
          <div class="kpi">
            <div class="label">Fokus</div>
            <div class="value" style="font-size:26px">${state.focus}</div>
            <div class="hint">Sykkel, løp eller begge</div>
          </div>
          <div class="kpi">
            <div class="label">Mål</div>
            <div class="value" style="font-size:24px">${latestGoal ? latestGoal.title : "Ingen ennå"}</div>
            <div class="hint">${latestGoal ? latestGoal.date : "Legg inn et mål"}</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="recommendation" style="background:linear-gradient(180deg,#0f172a 0%,#111827 100%)">
          <div class="small">Ukeoversikt</div>
          <h2>${phaseLabel()}</h2>
          <p>Dette er den roligste, smartest mulige uka gitt tiden du har nå.</p>
        </div>

        <div class="list" style="margin-top:14px">
          ${plan.slice(0, 3).map(dayCard).join("")}
        </div>

        <div class="hr"></div>

        <h3 class="section-title" style="font-size:18px;margin-bottom:6px">Kjapp kontroll</h3>
        <p class="section-sub">Her justerer du hva som styrer planen.</p>

        <div class="list">
          ${controlsHtml()}
        </div>
      </div>
    </div>

    <div class="grid cards" style="margin-top:16px">
      ${kpiCard("Kapasitet", "Lite støy", "Få, tydelige valg. Ikke masse grafer.", "🧠")}
      ${kpiCard("Livet først", "Planen tilpasser seg", "Treningen følger kalenderen din, ikke omvendt.", "🗓️")}
      ${kpiCard("Målenivå", "Kontinuitet", "Målet er å holde deg frisk og i form over tid.", "💙")}
    </div>
  `;

  document.getElementById("plan").innerHTML = `
    <div class="grid two">
      <div class="card">
        <h2 class="section-title">Tilgjengelighet</h2>
        <p class="section-sub">Legg inn hvor mange minutter du har per dag. Dette styrer planen.</p>
        <div class="list">
          ${state.availability.map(availabilityRow).join("")}
        </div>
      </div>
      <div class="card">
        <h2 class="section-title">Hvordan det fungerer</h2>
        <p class="section-sub">PeakPlan velger den enkleste gode planen.</p>
        <div class="list">
          ${infoRow("📅", "Tid først", "Uka styres av hvor mye tid du faktisk har.")}
          ${infoRow("🚴", "Pendling teller", "Sykkel til jobb blir en del av belastningen.")}
          ${infoRow("⚡", "Zwift", "Sykkeløkter kan merkes som eksportérbare.")}
          ${infoRow("🏃", "Løp", "Rolige turer og terskel tilpasses målene dine.")}
        </div>
      </div>
    </div>
  `;

  document.getElementById("goals").innerHTML = `
    <div class="grid two">
      <div class="card">
        <h2 class="section-title">Mål</h2>
        <p class="section-sub">Legg inn ritt og løp. Appen bruker dette til å velge fase og økter.</p>
        <div class="form-grid">
          <div class="field">
            <label>Navn</label>
            <input id="new-title" placeholder="Birken, halvmaraton..." />
          </div>
          <div class="field">
            <label>Type</label>
            <select id="new-type">
              <option>Ritt</option>
              <option>Løp</option>
              <option>Begge</option>
            </select>
          </div>
          <div class="field">
            <label>Dato</label>
            <input id="new-date" type="date" />
          </div>
          <div class="field">
            <label>Prioritet</label>
            <input id="new-priority" type="number" min="1" max="5" value="2" />
          </div>
          <div style="display:flex;align-items:end">
            <button class="btn primary" id="add-goal">Legg til</button>
          </div>
        </div>
        <div class="footer-note">Tips: Bruk ett viktig mål om gangen i starten. Det gir den beste planen.</div>
      </div>
      <div class="card">
        <h2 class="section-title">Dine mål</h2>
        <p class="section-sub">Dette er det PeakPlan planlegger bakover fra.</p>
        <div class="list">
          ${sortGoals(state.goals).map(goalRow).join("")}
        </div>
      </div>
    </div>
  `;

  document.getElementById("settings").innerHTML = `
    <div class="grid two">
      <div class="card">
        <h2 class="section-title">Tilpass</h2>
        <p class="section-sub">Noen få innstillinger som påvirker planen.</p>
        <div class="list">
          ${toggleRow("Inkluder Zwift-økter", "Sykkeløkter blir merket klare for eksport.", state.includeZwift, "zwift-toggle")}
        </div>
      </div>
      <div class="card">
        <h2 class="section-title">Tallene som betyr noe</h2>
        <p class="section-sub">Det som holder appen enkel og nyttig.</p>
        <div class="list">
          ${infoRow("🟢", "Livet først", "Treningen tilpasser seg hverdagen.")}
          ${infoRow("✅", "Én tydelig anbefaling", "Brukeren skal slippe å lure på hva som er lurt i dag.")}
          ${infoRow("❤️", "Frisk og rask", "Målet er å holde kontinuitet og overskudd.")}
          ${infoRow("🛡️", "Lite støy", "Få grafer. Få valg. Mer gjennomføring.")}
        </div>
      </div>
    </div>
  `;

  bindEvents(plan);
  save();
}

function kpiCard(title, big, desc, icon) {
  return `
    <div class="card">
      <div class="recommendation" style="background:#fff;color:var(--text);border:1px solid var(--border)">
        <div class="small" style="color:var(--muted)">${icon} ${title}</div>
        <h2 style="margin:10px 0 8px;color:var(--text)">${big}</h2>
        <p style="color:var(--muted)">${desc}</p>
      </div>
    </div>
  `;
}

function controlsHtml() {
  return `
    <div class="panel">
      <div class="field">
        <label>Fokus</label>
        <select id="focus">
          <option ${state.focus === "Sykkel" ? "selected" : ""}>Sykkel</option>
          <option ${state.focus === "Løp" ? "selected" : ""}>Løp</option>
          <option ${state.focus === "Begge" ? "selected" : ""}>Begge</option>
        </select>
      </div>
      <div class="field" style="margin-top:10px">
        <label>FTP (sykkel)</label>
        <input id="ftp" type="number" value="${state.ftp}" />
      </div>
      <div class="field" style="margin-top:10px">
        <label>Pendling dager/uke</label>
        <input id="commute-days" type="range" min="0" max="7" value="${state.commuteDays}" />
        <div class="muted" style="margin-top:4px">${state.commuteDays} dager</div>
      </div>
      <div class="field" style="margin-top:10px">
        <label>Pendlingstid per dag</label>
        <input id="commute-minutes" type="range" min="0" max="120" step="5" value="${state.commuteMinutes}" />
        <div class="muted" style="margin-top:4px">${state.commuteMinutes} min</div>
      </div>
      <button class="btn secondary" id="toggle-life" style="width:100%;margin-top:12px">${state.lifeHappened ? "Tilbake til normal" : "Livet skjedde"}</button>
      <div class="footer-note">Når livet skjer, blir planen roligere og enklere.</div>
    </div>
  `;
}

function dayCard(item) {
  const icon = item.type === "Sykkel" ? "🚴" : item.type === "Løp" ? "🏃" : item.type === "Pendling" ? "🧭" : "🛌";
  const zwift = item.zwift ? `<span class="small-badge">Zwift-klar</span>` : "";
  return `
    <div class="day-card">
      <div class="day-meta">
        <div class="icon">${icon}</div>
        <div>
          <h3 class="day-title">${DAY_LABELS[item.day]} <span class="small-badge">${item.type}</span>${zwift}</h3>
          <p class="day-desc"><strong>${item.title}</strong><br>${item.details}</p>
        </div>
      </div>
      <div class="small-badge">${item.duration ? item.duration + " min" : "Hvile"}</div>
    </div>
  `;
}

function availabilityRow(slot) {
  return `
    <div class="panel">
      <div class="field" style="margin-bottom:10px">
        <label>${DAY_LABELS[slot.day]}</label>
      </div>
      <div class="slider">
        <input type="range" min="0" max="240" step="5" value="${slot.minutes}" data-day="${slot.day}" class="minutes-slider" />
        <div class="small-badge" style="min-width:70px;text-align:center">${slot.minutes} min</div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 160px;gap:10px;margin-top:10px">
        <select data-day="${slot.day}" class="preferred-select">
          <option ${slot.preferred === "Sykkel" ? "selected" : ""}>Sykkel</option>
          <option ${slot.preferred === "Løp" ? "selected" : ""}>Løp</option>
          <option ${slot.preferred === "Begge" ? "selected" : ""}>Begge</option>
        </select>
        <button class="btn secondary" data-set-zero="${slot.day}">Nullstill</button>
      </div>
    </div>
  `;
}

function infoRow(icon, title, desc) {
  return `<div class="toggle"><div><div style="font-weight:800">${icon} ${title}</div><div class="muted" style="margin-top:4px;font-size:14px">${desc}</div></div></div>`;
}

function goalRow(goal) {
  return `
    <div class="day-card">
      <div>
        <h3 class="day-title">${goal.title}</h3>
        <p class="day-desc">${goal.date}<br><span class="small-badge">${goal.type}</span> <span class="small-badge">Prioritet ${goal.priority}</span></p>
      </div>
      <button class="btn danger" data-remove-goal="${goal.id}">Slett</button>
    </div>
  `;
}

function toggleRow(label, desc, enabled, id) {
  return `
    <button class="toggle" id="${id}">
      <div>
        <div style="font-weight:800">${label}</div>
        <div class="muted" style="margin-top:4px;font-size:14px">${desc}</div>
      </div>
      <div class="switch ${enabled ? "on" : ""}"><div class="knob"></div></div>
    </button>
  `;
}

function bindEvents(plan) {
  document.querySelectorAll("[data-go-tab]").forEach((btn) => {
    btn.onclick = () => {
      state.tab = btn.dataset.goTab;
      render();
    };
  });

  document.querySelectorAll(".tab").forEach((btn) => {
    btn.onclick = () => {
      state.tab = btn.dataset.tab;
      render();
    };
  });

  const lifeBtn = document.getElementById("toggle-life");
  if (lifeBtn) {
    lifeBtn.onclick = () => {
      state.lifeHappened = !state.lifeHappened;
      render();
    };
  }

  const zwiftToggle = document.getElementById("zwift-toggle");
  if (zwiftToggle) {
    zwiftToggle.onclick = () => {
      state.includeZwift = !state.includeZwift;
      render();
    };
  }

  document.querySelectorAll(".minutes-slider").forEach((slider) => {
    slider.oninput = (e) => {
      const day = e.target.dataset.day;
      const val = Number(e.target.value);
      state.availability = state.availability.map((item) => item.day === day ? { ...item, minutes: val } : item);
      render();
    };
  });

  document.querySelectorAll(".preferred-select").forEach((select) => {
    select.onchange = (e) => {
      const day = e.target.dataset.day;
      state.availability = state.availability.map((item) => item.day === day ? { ...item, preferred: e.target.value } : item);
      render();
    };
  });

  document.querySelectorAll("[data-set-zero]").forEach((btn) => {
    btn.onclick = () => {
      const day = btn.dataset.setZero;
      state.availability = state.availability.map((item) => item.day === day ? { ...item, minutes: 0 } : item);
      render();
    };
  });

  document.querySelectorAll("[data-remove-goal]").forEach((btn) => {
    btn.onclick = () => {
      state.goals = state.goals.filter((g) => g.id !== btn.dataset.removeGoal);
      render();
    };
  });

  const addGoalBtn = document.getElementById("add-goal");
  if (addGoalBtn) {
    addGoalBtn.onclick = () => {
      const title = document.getElementById("new-title").value.trim();
      const type = document.getElementById("new-type").value;
      const date = document.getElementById("new-date").value;
      const priority = Number(document.getElementById("new-priority").value || 2);
      if (!title || !date) return;
      state.goals = [...state.goals, { id: uid(), title, type, date, priority }];
      render();
    };
  }

  const ftpInput = document.querySelector("#ftp");
  if (ftpInput) {
    ftpInput.oninput = (e) => {
      state.ftp = Number(e.target.value);
      render();
    };
  }

  const focusSelect = document.querySelector("#focus");
  if (focusSelect) {
    focusSelect.onchange = (e) => {
      state.focus = e.target.value;
      render();
    };
  }

  const commuteDaysInput = document.querySelector("#commute-days");
  if (commuteDaysInput) {
    commuteDaysInput.oninput = (e) => {
      state.commuteDays = Number(e.target.value);
      render();
    };
  }

  const commuteMinutesInput = document.querySelector("#commute-minutes");
  if (commuteMinutesInput) {
    commuteMinutesInput.oninput = (e) => {
      state.commuteMinutes = Number(e.target.value);
      render();
    };
  }

  // rebuild partial UI controls inside home & settings, so keep fixed ids outside
  injectHomeControls();
}

function injectHomeControls() {
  const home = document.getElementById("home");
  const kpis = home?.querySelectorAll(".kpi .value");
  if (!kpis) return;
  // We keep home simple and render controls through JS not needed here.
}

function save() {
  localStorage.setItem("peakplan-alpha01", JSON.stringify(state));
}

function load() {
  const raw = localStorage.getItem("peakplan-alpha01");
  if (!raw) return;
  try {
    const parsed = JSON.parse(raw);
    Object.assign(state, parsed);
  } catch {}
}

load();

document.addEventListener("click", (e) => {
  const target = e.target.closest("[data-go-tab]");
  if (target) {
    state.tab = target.dataset.goTab;
    render();
  }
});

render();
