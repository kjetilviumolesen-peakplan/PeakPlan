const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const DAY_LABELS = {
  Mon: "Mandag",
  Tue: "Tirsdag",
  Wed: "Onsdag",
  Thu: "Torsdag",
  Fri: "Fredag",
  Sat: "Lørdag",
  Sun: "Søndag",
};
const GOAL_TYPES = ["Ritt", "Løp", "Begge"];
const FOCUS_OPTIONS = ["Sykkel", "Løp", "Begge"];
const LIFE_OPTIONS = [
  { id: "normal", label: "Normal uke", short: "normal" },
  { id: "sleep", label: "Sov dårlig", short: "roligere" },
  { id: "kids", label: "Barn syke", short: "roligere" },
  { id: "work", label: "Jobben dro ut", short: "roligere" },
  { id: "travel", label: "Reiser", short: "roligere" },
  { id: "tired", label: "Føler meg sliten", short: "roligere" },
  { id: "strong", label: "Føler meg sterk", short: "litt hardere" },
];

let state = {
  tab: "home",
  focus: "Begge",
  ftp: 295,
  commuteDays: 3,
  commuteMinutes: 45,
  includeZwift: true,
  lifeMode: "normal",
  availability: [
    { day: "Mon", minutes: 0, preferred: "Sykkel" },
    { day: "Tue", minutes: 50, preferred: "Løp" },
    { day: "Wed", minutes: 45, preferred: "Sykkel" },
    { day: "Thu", minutes: 75, preferred: "Løp" },
    { day: "Fri", minutes: 0, preferred: "Sykkel" },
    { day: "Sat", minutes: 120, preferred: "Sykkel" },
    { day: "Sun", minutes: 90, preferred: "Løp" },
  ],
  goals: [
    { id: uid(), title: "Birken sykkel", type: "Ritt", date: "2026-09-12", priority: 1 },
    { id: uid(), title: "Halvmaraton", type: "Løp", date: "2026-10-04", priority: 2 },
  ],
};

function uid() {
  return Math.random().toString(36).slice(2, 9);
}
function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function z2(ftp) { return `${Math.round(ftp * 0.56)}-${Math.round(ftp * 0.75)} W`; }
function tempo(ftp) { return `${Math.round(ftp * 0.76)}-${Math.round(ftp * 0.87)} W`; }
function sweetSpot(ftp) { return `${Math.round(ftp * 0.88)}-${Math.round(ftp * 0.94)} W`; }
function threshold(ftp) { return `${Math.round(ftp * 0.95)}-${Math.round(ftp * 1.05)} W`; }
function vo2(ftp) { return `${Math.round(ftp * 1.08)}-${Math.round(ftp * 1.18)} W`; }
function phaseFromGoal(goalDate) {
  if (!goalDate) return "Base";
  const diffDays = Math.ceil((new Date(goalDate).getTime() - Date.now()) / 86400000);
  if (diffDays > 84) return "Base";
  if (diffDays > 42) return "Build";
  if (diffDays > 14) return "Specific";
  return "Taper";
}
function makeInitialGoalDate() {
  return state.goals.slice().sort((a, b) => new Date(a.date) - new Date(b.date))[0]?.date || "";
}

function generateWeek() {
  const latestGoal = state.goals.slice().sort((a, b) => new Date(a.date) - new Date(b.date))[0];
  const phase = phaseFromGoal(latestGoal?.date || "");
  const available = state.availability.filter((d) => d.minutes > 0);
  const longest = [...available].sort((a, b) => b.minutes - a.minutes)[0] || available[0];
  const intervalDay = [...available].sort((a, b) => b.minutes - a.minutes)[1] || longest;
  const recoveryDay = available.find((d) => d.minutes <= 60) || available[0];
  const commuteDaysList = ["Mon", "Wed", "Fri"].filter(() => state.commuteDays > 0 && state.commuteMinutes > 0);
  const lifeAdjustment = state.lifeMode === "strong" ? "harder" : state.lifeMode === "normal" ? "normal" : "easier";

  return DAYS.map((day) => {
    const slot = state.availability.find((d) => d.day === day) || { minutes: 0, preferred: "Sykkel" };
    const commute = commuteDaysList.includes(day);

    if (!slot.minutes && !commute) {
      return { day, type: "Hvile", title: "Hvile", duration: 0, details: "Ingen planlagt økt.", zwift: false };
    }

    if (commute) {
      return {
        day,
        type: "Pendling",
        title: "Sykle til/fra jobb",
        duration: state.commuteMinutes,
        details: "Telles som lavintensivt volum og gir ekstra aerob trening uten ekstra planlegging.",
        zwift: false,
      };
    }

    if (day === longest.day) {
      const isRun = state.focus === "Løp" || (state.focus === "Begge" && slot.preferred === "Løp");
      const baseDuration = clamp(Math.round(slot.minutes * 0.9), 45, 180);
      const duration = lifeAdjustment === "easier" ? clamp(baseDuration - 15, 30, 150) : lifeAdjustment === "harder" ? clamp(baseDuration + 10, 50, 180) : baseDuration;
      return {
        day,
        type: isRun ? "Løp" : "Sykkel",
        title: isRun ? "Langtur rolig" : "Langkjøring sone 2",
        duration,
        details: isRun ? "Rolig pratetempo. Bygger kapasitet uten å stjele energi fra resten av uka." : `Hold jevnt i ${z2(state.ftp)}. Fokus på flyt og kontroll.`,
        zwift: !isRun && state.includeZwift,
      };
    }

    if (day === intervalDay.day && phase !== "Base") {
      const titles = { Build: "Sweet Spot", Specific: "VO2-økt", Taper: "Skarphet" };
      const details = {
        Build: `2 x 20 min i ${sweetSpot(state.ftp)} med 5 min pause.`,
        Specific: `5 x 4 min i ${vo2(state.ftp)} med kontrollert hard innsats.`,
        Taper: `6 x 2 min i ${tempo(state.ftp)}. Kort og skarpt.`,
      };
      const baseDuration = clamp(Math.round(slot.minutes * 0.8), 40, 110);
      const duration = lifeAdjustment === "easier" ? clamp(baseDuration - 10, 30, 100) : lifeAdjustment === "harder" ? clamp(baseDuration + 10, 45, 120) : baseDuration;
      return {
        day,
        type: state.focus === "Løp" ? "Løp" : "Sykkel",
        title: titles[phase] || "Terskel",
        duration,
        details: details[phase] || `3 x 12 min i ${threshold(state.ftp)}.`,
        zwift: state.focus !== "Løp" && state.includeZwift,
      };
    }

    if (day === recoveryDay.day) {
      const baseDuration = clamp(Math.round(slot.minutes * 0.6), 25, 60);
      const duration = lifeAdjustment === "easier" ? clamp(baseDuration - 5, 20, 45) : lifeAdjustment === "harder" ? clamp(baseDuration + 5, 30, 70) : baseDuration;
      return {
        day,
        type: state.focus === "Løp" ? "Løp" : "Sykkel",
        title: "Rolig restitusjon",
        duration,
        details: state.focus === "Løp" ? "Kort og lett jogg." : `Hold deg i ${z2(state.ftp)} og la beina hente seg inn.`,
        zwift: state.focus !== "Løp" && state.includeZwift,
      };
    }

    const isRun = state.focus === "Løp" || (state.focus === "Begge" && slot.preferred === "Løp");
    const baseDuration = clamp(Math.round(slot.minutes * 0.75), 30, 90);
    const duration = lifeAdjustment === "easier" ? clamp(baseDuration - 5, 20, 75) : lifeAdjustment === "harder" ? clamp(baseDuration + 5, 30, 100) : baseDuration;
    return {
      day,
      type: isRun ? "Løp" : "Sykkel",
      title: isRun ? "Rolig løp" : "Aerob base",
      duration,
      details: isRun ? "Snakkefart og lav friksjon." : `Jevn tråkking i ${z2(state.ftp)}.`,
      zwift: !isRun && state.includeZwift,
    };
  });
}

function render() {
  const latestGoal = state.goals.slice().sort((a, b) => new Date(a.date) - new Date(b.date))[0];
  const phase = phaseFromGoal(latestGoal?.date || "");
  const plan = generateWeek();
  const trainingMinutes = plan.filter((item) => item.type !== "Hvile").reduce((sum, item) => sum + item.duration, 0);
  const commuteLoad = state.commuteDays * state.commuteMinutes;
  const recommendedToday = plan.find((p) => p.duration > 0 && p.type !== "Hvile") || plan[0];
  const lifeLabel = LIFE_OPTIONS.find((o) => o.id === state.lifeMode)?.label || "Normal uke";

  document.title = "PeakPlan Alpha 0.1";
  document.getElementById("phase-pill").textContent = phase;
  document.getElementById("goal-pill").textContent = latestGoal ? latestGoal.title : "Ingen mål";
  document.getElementById("ftp-value").textContent = `${state.ftp} W`;
  document.getElementById("z2-value").textContent = `Sone 2: ${z2(state.ftp)}`;
  document.getElementById("focus-value").textContent = state.focus;
  document.getElementById("goal-value").textContent = latestGoal ? latestGoal.title : "Ingen ennå";
  document.getElementById("goal-date").textContent = latestGoal ? latestGoal.date : "Legg inn mål";
  document.getElementById("life-adjustment").textContent = `Aktuell justering: ${lifeLabel} (${state.lifeMode === "strong" ? "litt hardere" : state.lifeMode === "normal" ? "normal" : "roligere"})`;
  document.getElementById("rec-title").textContent = recommendedToday.title;
  document.getElementById("rec-text").textContent = recommendedToday.details;
  document.getElementById("rec-duration").textContent = `${recommendedToday.duration || 0} min`;
  document.getElementById("rec-type").textContent = recommendedToday.type;
  document.getElementById("rec-zwift").textContent = recommendedToday.zwift ? "Zwift-klar" : "Ikke Zwift";
  document.getElementById("week-plan").innerHTML = plan.map(renderPlanItem).join("");
  document.getElementById("availability-list").innerHTML = state.availability.map(renderAvailabilityRow).join("");
  document.getElementById("goals-list").innerHTML = state.goals.slice().sort((a, b) => new Date(a.date) - new Date(b.date)).map(renderGoalItem).join("");
  document.getElementById("commute-days-value").textContent = state.commuteDays;
  document.getElementById("commute-minutes-value").textContent = state.commuteMinutes;

  const lifeOptions = document.getElementById("life-options");
  lifeOptions.innerHTML = LIFE_OPTIONS.map((opt) => {
    const active = opt.id === state.lifeMode ? "active" : "";
    return `<button class="life-option ${active}" data-life="${opt.id}"><span>${opt.label}</span><span>${opt.short}</span></button>`;
  }).join("");
  lifeOptions.querySelectorAll("button").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.lifeMode = btn.dataset.life;
      render();
    });
  });

  document.getElementById("life-happened-btn").textContent = state.lifeMode === "normal" ? "Livet skjedde" : `Livet: ${lifeLabel}`;
  document.getElementById("goal-date").textContent = latestGoal ? latestGoal.date : "Legg inn mål";

  document.querySelectorAll(".tab").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.tab === state.tab);
  });
  document.querySelectorAll(".screen").forEach((screen) => {
    screen.classList.toggle("active", screen.id === `${state.tab}-screen`);
  });
}

function renderPlanItem(item) {
  const icon = item.type === "Sykkel" ? "🚴" : item.type === "Løp" ? "🏃" : item.type === "Pendling" ? "🗺️" : "🛌";
  return `
    <article class="plan-item">
      <div class="plan-left">
        <div class="plan-icon">${icon}</div>
        <div>
          <div class="plan-title">${DAY_LABELS[item.day]} · ${item.title}</div>
          <div class="plan-desc">${item.details}</div>
        </div>
      </div>
      <div class="plan-meta">
        <span class="pill">${item.type}</span>
        ${item.zwift ? '<span class="pill">Zwift-klar</span>' : ''}
        <span class="pill">${item.duration ? `${item.duration} min` : "Hvile"}</span>
      </div>
    </article>
  `;
}

function renderAvailabilityRow(slot) {
  return `
    <div class="availability-row">
      <strong>${DAY_LABELS[slot.day]}</strong>
      <div>
        <input type="range" min="0" max="240" step="5" value="${slot.minutes}" data-day="${slot.day}" class="availability-range" />
        <div class="hint">${slot.minutes} min</div>
      </div>
      <select data-day="${slot.day}" class="availability-sport">
        ${FOCUS_OPTIONS.map((opt) => `<option ${opt === slot.preferred ? "selected" : ""}>${opt}</option>`).join("")}
      </select>
    </div>
  `;
}

function renderGoalItem(goal) {
  return `
    <div class="goal-item">
      <div>
        <h3>${goal.title}</h3>
        <div class="goal-meta">${goal.type} · ${goal.date} · Prioritet ${goal.priority}</div>
      </div>
      <div class="goal-actions">
        <button data-remove-goal="${goal.id}" title="Slett mål">🗑</button>
      </div>
    </div>
  `;
}

function attachListeners() {
  document.querySelectorAll(".tab").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.tab = btn.dataset.tab;
      render();
      attachListeners();
    });
  });

  document.getElementById("focus-select").value = state.focus;
  document.getElementById("focus-select").addEventListener("change", (e) => {
    state.focus = e.target.value;
    render();
    attachListeners();
  });

  document.getElementById("ftp-input").value = state.ftp;
  document.getElementById("ftp-input").addEventListener("input", (e) => {
    state.ftp = Number(e.target.value || 0);
    render();
    attachListeners();
  });

  document.getElementById("commute-days").value = state.commuteDays;
  document.getElementById("commute-days").addEventListener("input", (e) => {
    state.commuteDays = Number(e.target.value);
    render();
    attachListeners();
  });

  document.getElementById("commute-minutes").value = state.commuteMinutes;
  document.getElementById("commute-minutes").addEventListener("input", (e) => {
    state.commuteMinutes = Number(e.target.value);
    render();
    attachListeners();
  });

  document.getElementById("life-happened-btn").addEventListener("click", () => {
    state.lifeMode = state.lifeMode === "normal" ? "tired" : "normal";
    render();
    attachListeners();
  });

  document.getElementById("goal-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const title = document.getElementById("goal-title").value.trim();
    const type = document.getElementById("goal-type").value;
    const date = document.getElementById("goal-date").value;
    const priority = Number(document.getElementById("goal-priority").value);
    if (!title || !date) return;
    state.goals.push({ id: uid(), title, type, date, priority });
    e.target.reset();
    document.getElementById("goal-type").value = "Ritt";
    document.getElementById("goal-priority").value = "2";
    render();
    attachListeners();
  });

  document.querySelectorAll("[data-remove-goal]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.goals = state.goals.filter((g) => g.id !== btn.dataset.removeGoal);
      render();
      attachListeners();
    });
  });

  document.querySelectorAll(".availability-range").forEach((input) => {
    input.addEventListener("input", (e) => {
      const day = e.target.dataset.day;
      const item = state.availability.find((x) => x.day === day);
      item.minutes = Number(e.target.value);
      render();
      attachListeners();
    });
  });

  document.querySelectorAll(".availability-sport").forEach((select) => {
    select.addEventListener("change", (e) => {
      const day = e.target.dataset.day;
      const item = state.availability.find((x) => x.day === day);
      item.preferred = e.target.value;
      render();
      attachListeners();
    });
  });
}

render();
attachListeners();
