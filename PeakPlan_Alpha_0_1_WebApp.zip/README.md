# PeakPlan Alpha 0.1

En enkel, mobilvennlig webapp for travle foreldre og mosjonister som vil trene smart uten mye støy.

## Dette er med i første versjon
- Én tydelig anbefaling på hjemskjermen
- Kalender for tilgjengelig tid
- Mål
- "Livet skjedde"
- Enkel ukeplan
- FTP og wattsoner
- Pendling som belastning
- Zwift-merking for sykkeløkter

## Slik bruker du filene
1. Last opp `index.html`, `styles.css`, `app.js` og `README.md` til GitHub-repoet ditt.
2. Koble repoet til Vercel eller GitHub Pages.
3. Åpne nettsiden på telefon eller Chromebook.

## Viktig
Dette er en første fungerende webversjon. Neste sprint kan vi legge til lagring, innlogging og Strava.
